NAME='router_static'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['router_static']
