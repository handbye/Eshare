NAME="objc_gc"
CFLAGS=["-fobjc-gc"]
LDFLAGS=[]
LIBS=[]
GCC_LIST=['objc_gc.m']
