NAME='clock_monotonic'

CFLAGS = []
LDFLAGS = []
LIBS = ['-lrt']
GCC_LIST = ['clock_monotonic']
